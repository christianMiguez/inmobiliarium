from django.contrib import admin
from inmobiliariumwebsite.models import Inmueble, InmuebleImagen

# Register your models here.
admin.site.register(Inmueble)
admin.site.register(InmuebleImagen)
